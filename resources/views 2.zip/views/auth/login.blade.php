<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - School System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Source+Sans+3:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --crimson: #c41e3a;
            --crimson-dark: #a01530;
            --crimson-light: #f9e8eb;
            --text-dark: #1a1a1a;
            --text-mid: #444;
            --text-light: #777;
            --border: #e5e5e5;
            --bg: #f7f7f5;
        }

        body {
            font-family: 'Source Sans 3', sans-serif;
            background: var(--bg);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ── NAVBAR ── */
        .site-navbar {
            background: #fff;
            border-bottom: 1px solid var(--border);
        }

        .navbar-top {
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 8px 0;
        }

        .navbar-top a {
            font-size: 13px;
            color: var(--text-mid);
            text-decoration: none;
            margin-left: 20px;
            transition: color .2s;
        }

        .navbar-top a:hover { color: var(--crimson); }

        .brand-logo {
            width: 42px; height: 42px;
            background: var(--crimson);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }

        .brand-logo i { color: white; font-size: 18px; }

        .brand-text strong {
            display: block;
            font-family: 'Playfair Display', serif;
            font-size: 14px;
            color: var(--text-dark);
            line-height: 1.1;
        }

        .brand-text small { font-size: 11px; color: var(--text-light); letter-spacing: .4px; }

        .btn-ask {
            background: #fff; border: 1.5px solid var(--crimson);
            color: var(--crimson); font-size: 13px; font-weight: 700;
            padding: 7px 16px; border-radius: 4px;
            display: inline-flex; align-items: center; gap: 6px; transition: all .2s;
        }
        .btn-ask:hover { background: var(--crimson-light); }

        .btn-enquire {
            background: #fff; border: 1.5px solid #ccc;
            color: var(--text-mid); font-size: 13px; font-weight: 700;
            padding: 7px 16px; border-radius: 4px;
            display: inline-flex; align-items: center; gap: 6px; transition: all .2s;
        }
        .btn-enquire:hover { border-color: var(--crimson); color: var(--crimson); }

        .btn-apply {
            background: var(--crimson); border: none; color: white;
            font-size: 13px; font-weight: 700; padding: 8px 18px; border-radius: 4px;
            display: inline-flex; align-items: center; gap: 6px; transition: background .2s;
        }
        .btn-apply:hover { background: var(--crimson-dark); color: white; }

        /* ── LOGIN AREA ── */
        .login-wrap {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 48px 16px;
        }

        .login-card {
            width: 100%;
            max-width: 440px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 24px rgba(0,0,0,.1);
            overflow: hidden;
            border: none;
        }

        .login-card-header {
            background: var(--crimson);
            padding: 30px 36px 26px;
            color: white;
        }

        .school-badge {
            display: flex; align-items: center; gap: 12px;
            margin-bottom: 16px;
        }

        .badge-icon {
            width: 48px; height: 48px;
            background: rgba(255,255,255,.2);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
        }
        .badge-icon i { font-size: 22px; color: white; }

        .badge-title {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            font-weight: 700;
            margin: 0 0 2px;
            line-height: 1.1;
        }

        .badge-sub {
            font-size: 12px;
            opacity: .85;
            margin: 0;
        }

        .login-subtitle {
            font-size: 15px;
            opacity: .9;
            margin: 0;
        }

        .login-body {
            padding: 32px 36px 36px;
        }

        .form-label {
            font-size: 14px;
            font-weight: 700;
            color: var(--text-mid);
            margin-bottom: 6px;
        }

        .form-control {
            border: 1.5px solid var(--border);
            border-radius: 5px;
            font-size: 14px;
            padding: 10px 12px;
            font-family: 'Source Sans 3', sans-serif;
            transition: border-color .2s, box-shadow .2s;
        }

        .form-control:focus {
            border-color: var(--crimson);
            box-shadow: 0 0 0 3px rgba(196,30,58,.1);
            outline: none;
        }

        .form-control.is-invalid { border-color: #dc3545; }

        .btn-login {
            width: 100%;
            background: var(--crimson);
            border: none;
            color: white;
            font-size: 15px;
            font-weight: 700;
            padding: 12px;
            border-radius: 5px;
            margin-top: 20px;
            display: inline-flex; align-items: center; justify-content: center; gap: 8px;
            transition: background .2s, transform .15s;
            cursor: pointer;
        }
        .btn-login:hover {
            background: var(--crimson-dark);
            transform: translateY(-1px);
        }

        .login-footer {
            border-top: 1px solid var(--border);
            margin-top: 24px;
            padding-top: 18px;
            text-align: center;
            font-size: 13px;
            color: var(--text-light);
            display: flex; align-items: center; justify-content: center; gap: 6px;
        }

        .demo-box {
            background: var(--crimson-light);
            border-left: 3px solid var(--crimson);
            padding: 14px 16px;
            border-radius: 5px;
            margin-top: 24px;
        }

        .demo-box h5 {
            color: var(--crimson);
            font-size: 13px;
            margin-bottom: 8px;
            font-weight: 700;
        }

        .demo-box p {
            color: var(--text-mid);
            margin: 4px 0;
            font-family: 'Courier New', monospace;
            font-size: 12.5px;
        }

        .demo-box strong { color: var(--text-dark); }

        @media (max-width: 480px) {
            .login-card-header { padding: 24px 24px 20px; }
            .login-body { padding: 24px 24px 28px; }
            .navbar-top .d-none-xs { display: none; }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
   

    <!-- Login -->
    <div class="login-wrap">
        <div class="login-card">

            <div class="login-card-header">
                <div class="school-badge">
                    <div class="badge-icon"><i class="bi bi-mortarboard-fill"></i></div>
                    <div>
                        <p class="badge-title">School System</p>
                        <p class="badge-sub">Fee Management Portal</p>
                    </div>
                </div>
                <p class="login-subtitle">Sign in to your account to continue</p>
            </div>

            <div class="login-body">

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show py-2 px-3 mb-3" style="font-size:14px;" role="alert">
                        @foreach ($errors->all() as $error)
                            <div><i class="bi bi-exclamation-circle me-1"></i>{{ $error }}</div>
                        @endforeach
                        <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                @if (session('success'))
                    <div class="alert alert-success alert-dismissible fade show py-2 px-3 mb-3" style="font-size:14px;" role="alert">
                        <i class="bi bi-check-circle me-1"></i>{{ session('success') }}
                        <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                <form method="POST" action="{{ route('login') }}" novalidate>
                    @csrf

                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input
                            type="email"
                            class="form-control @error('email') is-invalid @enderror"
                            id="email"
                            name="email"
                            value="{{ old('email') }}"
                            placeholder="Enter your email"
                            required
                            autofocus
                        >
                        @error('email')
                            <div class="invalid-feedback d-block" style="font-size:13px;">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-1">
                        <label for="password" class="form-label">Password</label>
                        <input
                            type="password"
                            class="form-control @error('password') is-invalid @enderror"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            required
                        >
                        @error('password')
                            <div class="invalid-feedback d-block" style="font-size:13px;">{{ $message }}</div>
                        @enderror
                    </div>

                    <button type="submit" class="btn-login">
                        <i class="bi bi-box-arrow-in-right"></i> Sign In
                    </button>
                </form>

                <!-- <div class="demo-box">
                    <h5>Demo Credentials:</h5>
                    <p><strong>Admin:</strong> admin@example.com / admin123</p>
                    <p><strong>User:</strong> user@example.com / password123</p>
                </div> -->

                <div class="login-footer">
                    <i class="bi bi-shield-lock"></i>
                    Secure admin access only
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>